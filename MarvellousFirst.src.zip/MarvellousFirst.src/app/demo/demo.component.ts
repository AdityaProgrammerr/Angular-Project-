import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent

{
 
    // Characteristics
    public name : string = "Marvllous Infosystems";
 

  ngOnInit(): void {
  }

}
